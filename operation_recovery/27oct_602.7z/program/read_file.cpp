#include "read_file.h"

list<PlaneType*>* getCoordinatesFromFile(char *filename) {
    filebuf fb;
    if (!fb.open(filename,ios::in)) {
        cerr << "An error occurred while opening file" << endl;
        return NULL;
    }
    istream fileInputStream(&fb);
    list<PlaneType*>* coordinatesList = new list<PlaneType*>();
    ThreePoints *tempThreePoints;

    int i;
    while(!fileInputStream.eof()) {
        tempThreePoints = new ThreePoints();

        // read 3 points
        for (i = 0;i < 3;i++) {
            fileInputStream >> tempThreePoints->set[i].x
                            >> tempThreePoints->set[i].y
                            >> tempThreePoints->set[i].z;
            if (fileInputStream.fail()) {
                if (!fileInputStream.eof())
                    fileInputStream.clear();
                break;
            }
        }

        // if all values have been read successfuly then push array to result list
        if (i == 3)
            coordinatesList->push_back(new PlaneType(*tempThreePoints));
        // then delete it
        delete tempThreePoints;
        // scipping remaining characters in current string
        while (!fileInputStream.eof() && fileInputStream.get() != '\n');
    }

    fb.close();
    return coordinatesList;
}
