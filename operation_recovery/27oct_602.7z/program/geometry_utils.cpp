#include "geometry_utils.h"

using namespace std;

template <typename T>
inline char sign(T t) {
    return (t > 0)? 1: (t < 0)? -1: 0;
}

bool isPointInsideTriangle(ThreePoints &t,Point &k) {
    Vector v0(Point(0,0,0)), v1(k,t.a()), v2(k,t.b()), v3(k,t.c());
    if (v1 == v0 || v2 == v0 || v3 == v0)
        return true;
    return sign(v1*v2) + sign(v1*v3) + sign(v2*v3) < 0;
}

Point* getPlaneAndLineIntersection(ThreePoints &plane,Line &line) {
    real coef1 = (plane.b().y - plane.a().y)*(plane.c().z - plane.a().z) -
            (plane.c().y - plane.a().y)*(plane.b().z - plane.a().z);
    real coef2 = (plane.b().x - plane.a().x)*(plane.c().z - plane.a().z) -
            (plane.c().x - plane.a().x)*(plane.b().z - plane.a().z);
    real coef3 = (plane.b().x - plane.a().x)*(plane.c().y - plane.a().y) -
            (plane.c().x - plane.a().x)*(plane.b().y - plane.a().y);
    real coef = ((line.a().x - plane.a().x)*coef1 -
                 (line.a().y - plane.a().y)*coef2 +
                 (line.a().z - plane.a().z)*coef3) /
                (line.directionVector.x*coef1 - line.directionVector.y*coef2 +
                 line.directionVector.z*coef3);

    // inf means that the line is parallel towards plane
    // nan means that the line belongs to plane
    if(isinf(coef) || isnan(coef)) {
        return new Point(coef,coef,coef);
    }

    return new Point(line.a().x - coef*line.directionVector.x,
                     line.a().y - coef*line.directionVector.y,
                     line.a().z - coef*line.directionVector.z);
}

bool doesLineIntersectTriangle(ThreePoints &triangle,Line &line) {
    Point *intersection = getPlaneAndLineIntersection(triangle,line);
    if (isinf(intersection->x)) {
        delete intersection;
        /// TODO: here should be checking whether the line intersects
        /// at least one of the triangles side
        /// for this function for finding two lines intersection should be
        /// implemented
        return false;
    }
    if (isnan(intersection->x)) {
        delete intersection;
        return false;
    }
    bool retVal = isPointInsideTriangle(triangle,*intersection);
    delete intersection;
    return retVal;
}
