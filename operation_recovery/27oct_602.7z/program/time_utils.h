#ifndef TIME_UTILS_H
#define TIME_UTILS_H

#include <unistd.h>
#include <ctime>
#include <cstdlib>
#include <iostream>
#include <random>
#include <functional>
using namespace std;

#define RAND(n) rand()%n

typedef uniform_real<double> Distribution;
typedef mt19937 Engine;
typedef variate_generator<Engine, Distribution> Generator;

extern int CLOCK_ID;

void printTimespec(timespec*);

timespec* getTimespecDelta(timespec*,timespec*);

double getRandom();

#endif // TIME_UTILS_H
