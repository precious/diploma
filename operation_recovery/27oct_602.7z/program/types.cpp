#include "types.h"

bool getOrientation() {
    return ORIENTATION;
}

void setOrientation(bool orientation) {
    ORIENTATION = orientation;
}


Point Point::operator+(Vector &v) {
    return Point(x + v.x,y + v.y, z + v.z);
}

Point Point::operator-(Vector &v) {
    return Point(x - v.x,y - v.y, z - v.z);
}

