#ifndef TYPES_H
#define TYPES_H

#include <iostream>
#include <string>
#include <stdexcept>
#include <cmath>
#include "time_utils.h"

using namespace std;

typedef float real;

#define RIGHT_HANDED 1
#define LEFT_HANDED 0

#define ORDER_CW 1
#define ORDER_CCW 0

static bool ORIENTATION = RIGHT_HANDED;
void setOrientation(bool);
bool getOrientation();


class InvalidPrimitiveException: public runtime_error {
public:
    InvalidPrimitiveException(string *msg): runtime_error(*msg) {}
    InvalidPrimitiveException(string &msg): runtime_error(msg) {}
};

struct Plane;
struct Vector;

struct Point {
    real x;
    real y;
    real z;

    Point(): x(0),y(0),z(0) {}
    Point(real _x, real _y, real _z): x(_x),y(_y),z(_z) {}
    Point(const Point &p) {x = p.x;y = p.y;z = p.z;}

    Point operator+(Vector &v);
    Point operator-(Vector &v);
    friend ostream& operator<<(ostream &os, const Point &p) {
        os << '(' << p.x << ',' << p.y << ',' << p.z << ')';
        return os;
    }
    bool operator==(Point &a) const {
        return (x == a.x && y == a.y && z == a.z);
    }
    Point rotateAroundZ(double cos,double sin) {
        return Point(x*cos - y*sin,x*sin + y*cos,z);
    }
    Point rotateAroundY(double cos,double sin) {
        return Point(x*cos + z*sin,y,-x*sin + z*cos);
    }
};

struct Vector: public Point {
    Vector(): Point() {}
    Vector(Point p): Point(p) {}
    Vector(real _x, real _y, real _z): Point(_x,_y,_z) {}
    Vector(Point b,Point a): Point(a.x - b.x,a.y - b.y,a.z - b.z) {}

    real operator*(Vector &right) {
        return x*right.x + y*right.y + z*right.z;
    }
    Vector operator*(double k) {
        return Vector(k*x,k*y,k*z);
    }
    Vector operator+(Vector &v) {
        return Vector(x + v.x,y + v.y, z + v.z);
    }
    Vector operator-(Vector &v) {
        return Vector(x - v.x,y - v.y, z - v.z);
    }
    real length() {
        return sqrt(x*x + y*y + z*z);
    }
    real cos(Vector &right) {
        return ((*this)*right)/(this->length()*right.length());
    }
};

template <unsigned int T>
struct Locus { // collection of points
    Point set[T];
    friend ostream& operator<<(ostream &os, const Locus &l) {
        for(unsigned int i = 0;i < T - 1;i++)
            os << l.set[i] << ", ";
        os << l.set[T - 1];
        return os;
    }
};

struct Line: public Locus<2> {
    Vector directionVector;
    Line(Point a,Point b) {
        set[0] = a; set[1] = b;
        directionVector = Vector(a,b);
    }
    Line(Point a,Vector v) {
        directionVector = v;
        set[0] = a;
        set[1] = a + v;
    }
    Point& a() {return set[0];}
    Point& b() {return set[1];}
};

struct ThreePoints: public Locus<3> {
    ThreePoints() {}
    ThreePoints(ThreePoints &tP) {
        set[0] = tP.set[0]; set[1] = tP.set[1]; set[2] = tP.set[2];
    }
    ThreePoints(Point _a,Point _b,Point _c) {
        set[0] = _a; set[1] = _b; set[2] = _c;
    }
    Point& a() {return set[0];}
    Point& b() {return set[1];}
    Point& c() {return set[2];}
};

struct Triangle: public ThreePoints {
    Triangle(Point _a,Point _b,Point _c): ThreePoints(_a,_b,_c) {}
    Triangle(ThreePoints &tP): ThreePoints(tP) {}
};

struct Plane: public ThreePoints {
    Plane(Point _a,Point _b,Point _c): ThreePoints(_a,_b,_c) {}
    Plane(ThreePoints &tP): ThreePoints(tP) {}
};

struct OrientedPlane: public Plane {
    Vector normal;
    OrientedPlane(Point _a,Point _b,Point _c, bool _pointsOrder = ORDER_CCW):
        Plane(_a,_b,_c), pointsOrder(_pointsOrder) {
        initNormal();
    }
    OrientedPlane(ThreePoints &tP,  bool _pointsOrder = ORDER_CCW):
        Plane(tP), pointsOrder(_pointsOrder) {
        initNormal();
    }
    OrientedPlane(Plane p, Vector v): Plane(p), normal(v) {}

private:
    bool pointsOrder;
    void initNormal() {
        Vector ab(a(),b());
        Vector ac(a(),c());
        // get cross product
        normal = Vector(ab.y*ac.z - ab.z*ac.y, -ab.x*ac.z + ab.z*ac.x, ab.x*ac.y - ab.y*ac.x);
        if (pointsOrder == ORDER_CW) {
            normal = normal*(-1);
        }
    }
};

struct Particle: public Point {
public:
    Vector direction;
    real weight;
    Particle(): Point(), direction(), weight(0) {}
    Particle(Point p, Vector d, real w): Point(p), direction(d), weight(w) {}
};

struct GenerativeSurface: public OrientedPlane {
private:
    // auxiliary constants
    double c0,c1,c2,c3,c4,c5,c6;
public:
    Point center;
    real radius;
    GenerativeSurface(OrientedPlane oP, Point _center, real _radius):
        OrientedPlane(oP,oP.normal), center(_center), radius(_radius) {
        init();
    }
    void init() {
        Vector &c = normal;
        Vector a(center, this->a());
        c0 = a.length();
        c1 = a.y - c.y*a.x/c.x;
        c2 = a.z - c.z*a.x/c.x;
        c3 = -c.y/(c.x*c1);
        c4 = c2*c.y/(c1*c.x) - c.z/c.x;
        c5 = c2*c2/(c1*c1) + c4*c4 + 1;
        c6 = 2*c3*c4 - 2*c2/(c1*c1);
        srand(time(NULL));
        /*cout << c0 << endl;
        cout << c1 << endl;
        cout << c2 << endl;
        cout << c3 << endl;
        cout << c4 << endl;
        cout << c5 << endl;
        cout << c6 << endl;*/
    }
    Point generatePoint() {
        real fi = getRandom()*2*M_PI, r = getRandom()*radius;
        real c8 = cos(fi)*c0*r;
        real c6_final = c6*c8;
        real c3_final = c3*c8;
        real c7 = c8*c8/(c1*c1) - r*r + c3_final*c3_final;
        Vector b;
        b.z = (-c6_final + (RAND(2)? 1: -1)*sqrt(c6_final*c6_final - 4*c5*c7))/(2*c5);
        b.y = c8/c1 - b.z*c2/c1;
        b.x = c3_final + b.z*c4;
        ////////////////////////////////cout << c6_final << "; " << c3_final << "; " << c3 << "; " << c7 << endl;
        return center + b;
    }
};



#endif // TYPES_H
