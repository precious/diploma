#ifndef GEOMETRY_UTILS_H
#define GEOMETRY_UTILS_H

#include "types.h"
#include <algorithm>
#include <iostream>
#include <cmath>
//#include

using namespace std;

bool isPointInsideTriangle(ThreePoints&,Point&);

Point* getPlaneAndLineIntersection(ThreePoints&,Line&);

bool doesLineIntersectTriangle(ThreePoints&,Line&);

#endif // GEOMETRY_UTILS_H
