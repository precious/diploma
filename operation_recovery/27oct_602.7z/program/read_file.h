#ifndef READ_FILE_H
#define READ_FILE_H

#include <iostream>
#include <fstream>
#include <list>
#include "types.h"
using namespace std;

typedef OrientedPlane PlaneType;

list<PlaneType*>* getCoordinatesFromFile(char*);

#endif // READ_FILE_H
