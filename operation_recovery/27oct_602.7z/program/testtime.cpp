#include <unistd.h>
#include <string.h>
#include <errno.h>

#include <ctime>
#include <cstdlib>
#include <iostream>
using namespace std;

#define init(type) (type*)memset(malloc(sizeof(type)),0,sizeof(type))
#define exitErr(msg) { cerr << msg << "\nerrno: " << errno << endl; exit(1); }

void printTimespec(timespec *ts) {
	cout << "seconds: " << ts->tv_sec << ", nanoseconds: " << ts->tv_nsec << endl;
}



int main(int argc, char **argv) {
	timespec *res = new timespec; //init(timespec);
	timespec *t = init(timespec);
	const int CLOCK_ID = CLOCK_THREAD_CPUTIME_ID;

	
	if (clock_gettime(CLOCK_ID,t))
		exitErr("1st gettime failed");
	printTimespec(t);
	long start = t->tv_nsec;
	
	//usleep(5000000);
	for(unsigned int i = 0;i < 2000000000;i++);
	
	if (clock_gettime(CLOCK_ID,t))
		exitErr("2nd gettime failed");
	printTimespec(t);
	cout << "delta: " << t->tv_nsec - start << endl;
	
	if (clock_getres(CLOCK_ID,res))
		exitErr("2nd getres failed");
	printTimespec(res);
	

	return 0;
}
